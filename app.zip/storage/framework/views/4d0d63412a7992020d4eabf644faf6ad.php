<div class="max-w-5xl p-6 mx-auto space-y-6">

    
    <div class="flex items-center justify-between">
    <h1 class="text-2xl font-semibold"><?php echo e($deck->name); ?></h1>

    <div class="flex items-center gap-2">
    <span class="text-sm text-gray-500">Due: <?php echo e($this->dueCount); ?></span>

    <a href="<?php echo e(route('study.panel', $deck)); ?>"
       class="px-3 py-2 text-sm text-white bg-black rounded hover:opacity-90">Study</a>

    <a href="<?php echo e(route('decks.analytics', $deck)); ?>"
       class="px-3 py-2 text-sm border rounded hover:bg-gray-50">Analytics</a>

    <a href="<?php echo e(route('decks.index')); ?>" class="text-sm underline">← Back</a>
    </div>

    </div>


    
    <!--[if BLOCK]><![endif]--><?php if(session('ok')): ?>
        <div class="p-3 text-sm text-green-800 bg-green-100 rounded"><?php echo e(session('ok')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <div class="grid gap-3 p-4 border rounded md:grid-cols-3">
        <div>
            <div class="mb-1 text-xs text-gray-500">Search</div>
            <input
                type="text"
                placeholder="Find in front/back/type…"
                wire:model.live.debounce.300ms="q"
                class="w-full px-3 py-2 border rounded focus:outline-none focus:ring focus:ring-gray-200"
            >
        </div>
        <div>
            <div class="mb-1 text-xs text-gray-500">Sort by</div>
            <select wire:model.live="sort" class="w-full px-3 py-2 border rounded">
                <option value="latest">Newest first</option>
                <option value="oldest">Oldest first</option>
                <option value="front_az">Front A → Z</option>
                <option value="front_za">Front Z → A</option>
            </select>
        </div>
        <div>
            <div class="mb-1 text-xs text-gray-500">Per page</div>
            <select wire:model.live="perPage" class="w-full px-3 py-2 border rounded">
                <option>5</option>
                <option selected>10</option>
                <option>15</option>
                <option>20</option>
                <option>30</option>
                <option>50</option>
            </select>
        </div>
    </div>

    
    <div class="flex items-center justify-between">
        <div class="text-sm text-gray-500">
            <?php echo e($items->total()); ?> item(s)
        </div>
        <button
            wire:click="openCreate"
            class="px-4 py-2 text-white bg-black rounded hover:opacity-90"
        >
            + New flashcard
        </button>
    </div>

    
    <div class="border divide-y rounded">
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $it): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="p-4 space-y-2">
                <div class="text-xs text-gray-400">
                    #<?php echo e($it->id); ?> • <?php echo e($it->created_at?->diffForHumans()); ?> • Type: <?php echo e($it->type); ?>

                </div>

                <div class="flex items-start justify-between gap-4">
                    <div class="min-w-0">
                        <div class="font-medium break-words">Q: <?php echo e($it->front); ?></div>
                        <div class="mt-1 text-sm text-gray-700 break-words">A: <?php echo e($it->back); ?></div>
                    </div>
                    <div class="space-x-2 shrink-0">
                        <button
                            wire:click="openEdit(<?php echo e($it->id); ?>)"
                            class="text-sm underline"
                        >Edit</button>
                        <button
                            wire:click="deleteItem(<?php echo e($it->id); ?>)"
                            class="text-sm text-red-600 underline"
                        >Delete</button>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="p-4 text-gray-500">No items found.</div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <div>
        <?php echo e($items->links()); ?>

    </div>

    
    <!--[if BLOCK]><![endif]--><?php if($showCreate): ?>
        <dialog open class="w-full max-w-xl p-0 rounded-lg shadow-2xl">
            <div class="p-5 space-y-3">
                <div class="text-lg font-semibold">New flashcard</div>

                <input
                    type="text"
                    placeholder="Front (question / term)…"
                    wire:model="createFront"
                    class="w-full px-3 py-2 border rounded focus:outline-none focus:ring focus:ring-gray-200"
                >
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['createFront'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-sm text-red-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                <textarea
                    placeholder="Back (answer / definition)…"
                    wire:model="createBack"
                    class="border rounded px-3 py-2 w-full min-h-[120px] focus:outline-none focus:ring focus:ring-gray-200"
                ></textarea>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['createBack'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-sm text-red-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                <div class="flex items-center justify-end gap-2 pt-2">
                    <button wire:click="closeCreate" class="px-4 py-2 border rounded">Cancel</button>
                    <button wire:click="storeItem" class="px-4 py-2 text-white bg-black rounded hover:opacity-90">Create</button>
                </div>
            </div>
        </dialog>
        <div class="fixed inset-0 bg-black/40"></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <!--[if BLOCK]><![endif]--><?php if($showEdit): ?>
        <dialog open class="w-full max-w-xl p-0 rounded-lg shadow-2xl">
            <div class="p-5 space-y-3">
                <div class="text-lg font-semibold">Edit flashcard #<?php echo e($editId); ?></div>

                <input
                    type="text"
                    placeholder="Front…"
                    wire:model="editFront"
                    class="w-full px-3 py-2 border rounded focus:outline-none focus:ring focus:ring-gray-200"
                >
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['editFront'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-sm text-red-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                <textarea
                    placeholder="Back…"
                    wire:model="editBack"
                    class="border rounded px-3 py-2 w-full min-h-[120px] focus:outline-none focus:ring focus:ring-gray-200"
                ></textarea>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['editBack'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="text-sm text-red-600"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                <div class="flex items-center justify-between pt-2">
                    <button wire:click="closeEdit" class="px-4 py-2 border rounded">Cancel</button>
                    <div class="space-x-2">
                        <button wire:click="updateItem" class="px-4 py-2 text-white bg-black rounded hover:opacity-90">Save</button>
                    </div>
                </div>
            </div>
        </dialog>
        <div class="fixed inset-0 bg-black/40"></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\All code\PjFlash\resources\views/livewire/decks/deck-show.blade.php ENDPATH**/ ?>