


<?php
    $front = trim((string)($item->front ?? ''));
    $back  = trim((string)($item->back ?? ''));
    $data  = $item->data ?? [];
?>

<div class="p-6 space-y-4 bg-white border shadow-sm rounded-2xl">
    
    <div>
        <div class="mb-2 text-xs text-gray-400 uppercase">Question</div>
        <!--[if BLOCK]><![endif]--><?php if($front !== ''): ?>
            <div class="prose max-w-none"><?php echo e($front); ?></div>
        <?php elseif(!empty($data)): ?>
            <pre class="p-3 overflow-x-auto text-xs rounded-lg bg-gray-50"><?php echo e(json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
        <?php else: ?>
            <div class="text-sm text-gray-400">Không có nội dung mặt trước.</div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <!--[if BLOCK]><![endif]--><?php if(!$showAnswer): ?>
        <div>
            <button
                wire:click="$set('showAnswer', true)"
                class="px-4 py-2 text-white bg-black rounded-lg hover:opacity-90"
            >
                Show Answer
            </button>
        </div>
    <?php else: ?>
        <div class="p-4 border rounded-xl bg-emerald-50/40">
            <div class="mb-2 text-xs text-gray-500 uppercase">Answer</div>
            <!--[if BLOCK]><![endif]--><?php if($back !== ''): ?>
                <div class="prose max-w-none"><?php echo e($back); ?></div>
            <?php elseif(!empty($data)): ?>
                <pre class="p-3 overflow-x-auto text-xs bg-white rounded-lg"><?php echo e(json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)); ?></pre>
            <?php else: ?>
                <div class="text-sm text-gray-400">Không có nội dung mặt sau.</div>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </div>

        
        <div class="flex flex-wrap items-center gap-2">
            <button wire:click="grade(0)" class="px-3 py-2 rounded-xl bg-red-50 hover:bg-red-100">Again</button>
            <button wire:click="grade(1)" class="px-3 py-2 rounded-xl bg-amber-50 hover:bg-amber-100">Hard</button>
            <button wire:click="grade(2)" class="px-3 py-2 rounded-xl bg-emerald-50 hover:bg-emerald-100">Good</button>
            <button wire:click="grade(3)" class="px-3 py-2 rounded-xl bg-blue-50 hover:bg-blue-100">Easy</button>

            <button
                wire:click="$set('showAnswer', false)"
                class="px-3 py-2 ml-auto text-xs border rounded-lg hover:bg-gray-50"
                title="Ẩn đáp án"
            >
                Hide
            </button>
        </div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\All code\PjFlash\resources\views/study/partials/flashcard.blade.php ENDPATH**/ ?>