
<div class="max-w-3xl p-6 mx-auto space-y-6">

    
    <?php
        $progress = min(100, (int) round(($reviewsThisSession / max(1,$maxReviewsPerSession)) * 100));
        $milestones = [10, 50, 100]; // NOTE: mốc badge
    ?>

    <div class="space-y-2">
        <div class="flex flex-wrap items-center gap-3 text-sm text-gray-600">
            <div><span class="font-medium"><?php echo e($deck->name); ?></span></div>
            <span class="hidden sm:inline">•</span>
            <div>
                Reviews: <span class="font-semibold"><?php echo e($reviewsThisSession); ?></span>/<span><?php echo e($maxReviewsPerSession); ?></span>
            </div>
            <span class="hidden sm:inline">•</span>
            <div>
                New today: <span class="font-semibold"><?php echo e($newThisSession); ?></span>/<span><?php echo e($maxNewPerSession); ?></span>
            </div>
            <span class="hidden sm:inline">•</span>
            <div>Due remaining: <span class="font-semibold"><?php echo e($dueRemaining); ?></span></div>
            <span class="hidden sm:inline">•</span>
            <div>New remaining: <span class="font-semibold"><?php echo e($newRemaining); ?></span></div>
        </div>

        
        <div class="w-full h-2 overflow-hidden bg-gray-100 rounded-full">
            <div class="h-2 bg-gray-900" style="width: <?php echo e($progress); ?>%"></div>
        </div>

        
        <div class="flex items-center gap-2 text-xs">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $milestones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'px-2 py-1 rounded-full border',
                        // đạt mốc -> nổi bật
                        'bg-emerald-50 border-emerald-300 text-emerald-700' => $reviewsThisSession >= $m,
                        // chưa đạt -> mờ
                        'bg-gray-50 border-gray-200 text-gray-500' => $reviewsThisSession < $m,
                    ]); ?>"
                    title="Milestone <?php echo e($m); ?> reviews"
                >
                    🎯 <?php echo e($m); ?>

                </span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    
    <div class="flex flex-wrap items-center justify-between gap-3">
        
        <?php echo $__env->make('study.partials.mode-switcher', ['mode' => $mode], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        
        <div class="flex items-center gap-2 text-sm">
            <span class="text-gray-500">Queue:</span>
            <div class="flex gap-1">
                <button wire:click="setQueueMode('due')"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'px-3 py-1.5 rounded-xl border',
                            $queueMode === 'due' ? 'bg-gray-900 text-white border-gray-900' : 'bg-white hover:bg-gray-50'
                        ]); ?>">Only due</button>
                <button wire:click="setQueueMode('mix')"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'px-3 py-1.5 rounded-xl border',
                            $queueMode === 'mix' ? 'bg-gray-900 text-white border-gray-900' : 'bg-white hover:bg-gray-50'
                        ]); ?>">Mix</button>
                <button wire:click="setQueueMode('new')"
                        class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                            'px-3 py-1.5 rounded-xl border',
                            $queueMode === 'new' ? 'bg-gray-900 text-white border-gray-900' : 'bg-white hover:bg-gray-50'
                        ]); ?>">Only new</button>
            </div>
        </div>
    </div>

    
    <!--[if BLOCK]><![endif]--><?php if($sessionEnded): ?>
        <div class="p-10 text-center bg-white border shadow-sm rounded-2xl">
            <h3 class="text-lg font-semibold">Session complete 🎉</h3>
            <p class="mt-1 text-sm text-gray-500">
                Không còn thẻ theo chế độ <strong><?php echo e(strtoupper($queueMode)); ?></strong>
                hoặc bạn đã đạt giới hạn phiên.
            </p>
            <div class="flex items-center justify-center gap-2 mt-4">
                <a href="<?php echo e(route('decks.show', $deck)); ?>" class="px-4 py-2 border rounded-lg hover:bg-gray-50">Back to deck</a>
                <button wire:click="$refresh" class="px-4 py-2 text-white bg-black rounded-lg hover:opacity-90">
                    Refresh
                </button>
            </div>
        </div>
    <?php else: ?>
        <?php
            $itemType = is_object($current?->type) ? ($current?->type->value ?? 'flashcard') : ($current?->type ?? 'flashcard');
            $viewMode = $mode === 'auto' ? $itemType : $mode;

            if ($mode === 'auto') {
                $choices    = data_get($current->data ?? [], 'mcq.options', []);
                $pairs      = data_get($current->data ?? [], 'matching.pairs', []);
                $noMcq      = !is_array($choices) || count($choices) < 2;
                $noMatching = !is_array($pairs)   || count($pairs)   === 0;
                if ($viewMode === 'mcq' && $noMcq)           $viewMode = 'flashcard';
                if ($viewMode === 'matching' && $noMatching) $viewMode = 'flashcard';
            }
        ?>

        <div class="flex items-center justify-between text-xs text-gray-500">
            <div>Mode: <span class="font-medium uppercase"><?php echo e($viewMode); ?></span> • Queue: <span class="font-medium uppercase"><?php echo e($queueMode); ?></span></div>
            <div>ID: <?php echo e($current?->id); ?></div>
        </div>

        <!--[if BLOCK]><![endif]--><?php if(!$current): ?>
            <div class="p-10 text-center bg-white border shadow-sm rounded-2xl">
                <h3 class="text-lg font-semibold">Không có thẻ để học.</h3>
            </div>
        <?php else: ?>
            <!--[if BLOCK]><![endif]--><?php if($viewMode === 'mcq'): ?>
                <?php echo $__env->make('study.partials.mcq', ['item' => $current], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php elseif($viewMode === 'matching'): ?>
                <?php echo $__env->make('study.partials.matching', ['item' => $current], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php else: ?>
                <?php echo $__env->make('study.partials.flashcard', ['item' => $current, 'showAnswer' => $showAnswer], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\All code\PjFlash\resources\views/livewire/study/study-panel.blade.php ENDPATH**/ ?>