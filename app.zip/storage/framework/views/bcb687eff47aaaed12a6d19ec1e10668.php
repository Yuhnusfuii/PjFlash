
<?php $__env->startPush('styles'); ?>
<style>
  /* CSS riêng cho trang này (tuỳ chọn) */
  .hero { background: radial-gradient(1200px 600px at 10% 0%, #e0f2fe 0, transparent 60%); }
</style>
<?php $__env->stopPush(); ?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl leading-tight">Dashboard</h2>
   <?php $__env->endSlot(); ?>

  <?php
    $uid = auth()->id();
    $deckCount = \App\Models\Deck::where('user_id',$uid)->count();
    $itemCount = \App\Models\Item::whereHas('deck', fn($q)=>$q->where('user_id',$uid))->count();
    $dueToday  = \App\Models\ReviewState::where('user_id',$uid)->where('due_at','<=',now())->count();
    $decks     = \App\Models\Deck::withCount('items')->where('user_id',$uid)->latest()->take(8)->get();
  ?>

  <div class="container-app py-6 space-y-6">
    <div class="grid gap-4 md:grid-cols-3">
      <div class="card p-6">
        <div class="text-sm text-slate-500">Due today</div>
        <div class="text-3xl font-semibold"><?php echo e($dueToday); ?></div>
      </div>
      <div class="card p-6">
        <div class="text-sm text-slate-500">Total decks</div>
        <div class="text-3xl font-semibold"><?php echo e($deckCount); ?></div>
      </div>
      <div class="card p-6">
        <div class="text-sm text-slate-500">Total items</div>
        <div class="text-3xl font-semibold"><?php echo e($itemCount); ?></div>
      </div>
    </div>

    <div class="card p-6">
      <div class="flex items-center justify-between mb-4">
        <h3 class="text-lg font-medium">Your latest decks</h3>
        <a href="<?php echo e(url('/decks')); ?>" class="btn-outline">All decks</a>
      </div>
      <ul class="divide-y divide-slate-200 dark:divide-slate-700">
        <?php $__empty_1 = true; $__currentLoopData = $decks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <li class="py-3 flex items-center justify-between">
            <div>
              <div class="font-semibold"><?php echo e($d->name); ?></div>
              <div class="text-sm text-slate-500"><?php echo e($d->items_count); ?> items</div>
            </div>
          </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <li class="py-6 text-slate-500">No decks yet.</li>
        <?php endif; ?>
      </ul>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>


<?php $__env->startPush('scripts'); ?>
<script>
  // JS riêng cho Dashboard (nếu cần)
</script>
<?php $__env->stopPush(); ?>
<?php /**PATH D:\All code\PjFlash\resources\views/dashboard.blade.php ENDPATH**/ ?>