<div class="max-w-6xl mx-auto p-6 space-y-6">

    
    <!--[if BLOCK]><![endif]--><?php if(session('ok')): ?>
        <div class="p-3 rounded bg-green-100 text-green-800 text-sm"><?php echo e(session('ok')); ?></div>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

    
    <div class="flex items-center gap-3">
        <input
            type="text"
            placeholder="Search decks..."
            wire:model.live.debounce.300ms="q"
            class="border rounded px-3 py-2 w-full focus:outline-none focus:ring focus:ring-gray-200"
        >
        <a href="<?php echo e(route('decks.index')); ?>" class="text-sm underline">Reset</a>
    </div>

    
    <div class="flex items-center gap-2">
        <input
            type="text"
            placeholder="New deck name..."
            wire:model="newName"
            class="border rounded px-3 py-2 w-full focus:outline-none focus:ring focus:ring-gray-200"
        >
        <button wire:click="createDeck" class="px-4 py-2 rounded bg-black text-white hover:opacity-90">
            Create
        </button>
    </div>

    
    <div class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <!--[if BLOCK]><![endif]--><?php $__empty_1 = true; $__currentLoopData = $decks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="group border rounded-xl p-4 hover:shadow-sm transition bg-white">
                
                <div class="flex items-center justify-between">
                    <div class="text-xs text-gray-500"><?php echo e($deck->created_at?->diffForHumans()); ?></div>
                    <div class="text-[11px] px-2 py-1 rounded border text-gray-600 bg-gray-50">
                        #<?php echo e($deck->id); ?>

                    </div>
                </div>

                
                <div class="mt-2 text-lg font-semibold line-clamp-2">
                    <a href="<?php echo e(route('decks.show', $deck)); ?>"
                       class="hover:underline decoration-2">
                        <?php echo e($deck->name); ?>

                    </a>
                </div>

                
                <!--[if BLOCK]><![endif]--><?php if(!empty($deck->description)): ?>
                    <div class="mt-2 text-sm text-gray-600 line-clamp-2">
                        <?php echo e($deck->description); ?>

                    </div>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                <div class="mt-4 flex items-center justify-between">
                    
                    <span class="text-xs text-gray-500">
                        
                    </span>

                    <div class="flex items-center gap-2">
                        <a href="<?php echo e(route('decks.show', $deck)); ?>"
                           class="px-3 py-1.5 rounded border text-sm hover:bg-gray-50">
                            Open
                        </a>
                        <a href="<?php echo e(route('study.panel', $deck)); ?>"
                           class="px-3 py-1.5 rounded bg-black text-white text-sm hover:opacity-90">
                            Study
                        </a>
                        <a href="<?php echo e(route('decks.analytics', $deck)); ?>"
                           class="px-3 py-1.5 rounded border text-sm hover:bg-gray-50">
                            Analytics
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-full text-gray-500">No decks found.</div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>

    
    <div>
        <?php echo e($decks->links()); ?>

    </div>
</div>
<?php /**PATH D:\All code\PjFlash\resources\views/livewire/decks/deck-index.blade.php ENDPATH**/ ?>