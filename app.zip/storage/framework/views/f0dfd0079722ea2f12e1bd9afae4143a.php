<?php
  $is = fn($p) => request()->routeIs($p);
?>

<nav class="border-b border-slate-200 dark:border-slate-700 bg-white/80 dark:bg-slate-900/80 backdrop-blur">
  <div class="container-app h-16 flex items-center justify-between">
    
    <div class="flex items-center gap-6">
      <a href="<?php echo e(route('home')); ?>" class="flex items-center gap-2 font-semibold">
        <?php if (isset($component)) { $__componentOriginal8892e718f3d0d7a916180885c6f012e7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8892e718f3d0d7a916180885c6f012e7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.application-logo','data' => ['class' => 'h-6 w-6 text-brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('application-logo'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'h-6 w-6 text-brand']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $attributes = $__attributesOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__attributesOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8892e718f3d0d7a916180885c6f012e7)): ?>
<?php $component = $__componentOriginal8892e718f3d0d7a916180885c6f012e7; ?>
<?php unset($__componentOriginal8892e718f3d0d7a916180885c6f012e7); ?>
<?php endif; ?>
        <span>PjFlash</span>
      </a>

      <div class="hidden md:flex items-center gap-4">
        <a href="<?php echo e(route('home')); ?>" class="<?php echo e($is('home') ? 'text-brand' : 'text-slate-600 dark:text-slate-300'); ?>">Home</a>
        <?php if(auth()->guard()->check()): ?>
          <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e($is('dashboard') ? 'text-brand' : 'text-slate-600 dark:text-slate-300'); ?>">Dashboard</a>
          <a href="<?php echo e(route('decks.index')); ?>" class="<?php echo e(request()->is('decks*') ? 'text-brand' : 'text-slate-600 dark:text-slate-300'); ?>">Decks</a>
          <a href="<?php echo e(route('items.index')); ?>" class="<?php echo e(request()->is('items*') ? 'text-brand' : 'text-slate-600 dark:text-slate-300'); ?>">Items</a>
          <a href="<?php echo e(route('analytics.index')); ?>" class="<?php echo e(request()->is('analytics*') ? 'text-brand' : 'text-slate-600 dark:text-slate-300'); ?>">Analytics</a>
        <?php endif; ?>
      </div>
    </div>

    
    <div class="flex items-center gap-2">
      <button data-theme-toggle class="inline-flex items-center justify-center px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800" title="Toggle theme">🌙</button>

      <div class="hidden sm:flex sm:items-center sm:ml-6">
        <?php if(auth()->guard()->check()): ?>
          <?php echo $__env->renderWhen(View::exists('layouts.partials.user-dropdown'), 'layouts.partials.user-dropdown', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1])); ?>
        <?php else: ?>
          <a href="<?php echo e(route('login')); ?>" class="btn-outline">Đăng nhập</a>
        <?php endif; ?>
      </div>

      <button
        data-mobile-toggle
        class="md:hidden inline-flex items-center justify-center px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800"
        aria-expanded="false" aria-label="Open Menu">☰</button>
      <form method="POST" action="<?php echo e(route('logout')); ?>" class="ml-3 hidden md:block">
      <?php echo csrf_field(); ?>
      <button type="submit" class="btn-outline text-sm">
        Đăng xuất
      </button>
       </form>

    </div>
  </div>
</nav>


<div data-mobile-panel class="hidden md:hidden border-t border-slate-200 dark:border-slate-700">
  <div class="px-4 py-3 space-y-2">
    <a href="<?php echo e(route('home')); ?>" class="block px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 <?php echo e($is('home') ? 'bg-slate-100 dark:bg-slate-800 text-brand' : ''); ?>">Home</a>
    <?php if(auth()->guard()->check()): ?>
      <a href="<?php echo e(route('dashboard')); ?>" class="block px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 <?php echo e($is('dashboard') ? 'bg-slate-100 dark:bg-slate-800 text-brand' : ''); ?>">Dashboard</a>
      <a href="<?php echo e(route('decks.index')); ?>" class="block px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 <?php echo e(request()->is('decks*') ? 'bg-slate-100 dark:bg-slate-800 text-brand' : ''); ?>">Decks</a>
      <a href="<?php echo e(route('items.index')); ?>" class="block px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 <?php echo e(request()->is('items*') ? 'bg-slate-100 dark:bg-slate-800 text-brand' : ''); ?>">Items</a>
      <a href="<?php echo e(route('analytics.index')); ?>" class="block px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800 <?php echo e(request()->is('analytics*') ? 'bg-slate-100 dark:bg-slate-800 text-brand' : ''); ?>">Analytics</a>
    <?php else: ?>
      <a href="<?php echo e(route('login')); ?>" class="block px-3 py-2 rounded-2xl hover:bg-slate-100 dark:hover:bg-slate-800">Đăng nhập</a>
    <?php endif; ?>
  </div>
  <div class="px-4 py-3 border-t border-slate-200 dark:border-slate-700">
  <form method="POST" action="<?php echo e(route('logout')); ?>">
    <?php echo csrf_field(); ?>
    <button type="submit" class="w-full btn-outline">
      Đăng xuất
    </button>
  </form>
</div>

</div>
<?php /**PATH D:\All code\PjFlash\resources\views/layouts/navigation.blade.php ENDPATH**/ ?>