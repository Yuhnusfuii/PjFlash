


<?php
    $modes = [
        'auto'      => 'Auto',
        'flashcard' => 'Flashcard',
        'mcq'       => 'MCQ',
        'matching'  => 'Matching',
    ];
?>

<div class="flex flex-wrap gap-2">
    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $modes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button
            wire:click="setMode('<?php echo e($key); ?>')"
            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'px-3 py-1.5 rounded-xl border text-sm transition',
                'bg-gray-900 text-white border-gray-900' => $mode === $key,
                'bg-white hover:bg-gray-50' => $mode !== $key,
            ]); ?>"
            title="Switch to <?php echo e($label); ?>"
        >
            <?php echo e($label); ?>

        </button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH D:\All code\PjFlash\resources\views/study/partials/mode-switcher.blade.php ENDPATH**/ ?>