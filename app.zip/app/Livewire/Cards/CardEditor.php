<?php

namespace App\Livewire\Cards;

use Livewire\Component;

class CardEditor extends Component
{
    public function render()
    {
        return view('livewire.cards.card-editor');
    }
}
