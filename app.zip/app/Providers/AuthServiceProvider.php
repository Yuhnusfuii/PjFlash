<?php

namespace App\Providers;

use App\Models\Deck;
use App\Models\Item;
use App\Models\ReviewState;
use App\Policies\DeckPolicy;
use App\Policies\ItemPolicy;
use App\Policies\ReviewStatePolicy;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    protected $policies = [
        Deck::class        => DeckPolicy::class,
        Item::class        => ItemPolicy::class,
        ReviewState::class => ReviewStatePolicy::class,
    ];

    public function boot(): void
    {
        $this->registerPolicies();
    }
}
