<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DeckController extends Controller
{
    public function __construct()
    {
        // Bảo vệ toàn bộ controller bằng Sanctum
        $this->middleware('auth:sanctum');
    }

    /**
     * GET /api/decks
     * Trả về danh sách deck của user đang đăng nhập (paginate).
     */
    public function index(Request $request)
    {
        $decks = $request->user()->decks()
            ->select(['id', 'title', 'description', 'created_at', 'updated_at'])
            ->latest('id')
            ->paginate(20);

        return response()->json($decks);
    }

    /**
     * POST /api/decks/{deck}/import
     * Placeholder cho bước 10 (import lớn sẽ đẩy vào queue).
     */
    public function import(Request $request)
    {
        return response()->json(['ok' => true, 'message' => 'Import placeholder']);
    }
}
