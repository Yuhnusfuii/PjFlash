<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

// OAuth (Google)
use App\Http\Controllers\Auth\GoogleController;

// Livewire pages
use App\Livewire\Decks\DeckIndex;
use App\Livewire\Decks\DeckShow;
use App\Livewire\Study\StudyPanel;
use App\Livewire\Analytics\DeckAnalytics;
use App\Livewire\Analytics\DecksOverview;

/*
|--------------------------------------------------------------------------
| WEB ROUTES
|--------------------------------------------------------------------------
| Chỉ để các trang giao diện web (login, dashboard, livewire, oauth).
| Toàn bộ API (MCQ/Matching/Review…) để trong routes/api.php để tránh trùng.
*/

// PUBLIC
Route::view('/', 'home')->name('home');

// Google OAuth (cần cho nút "Login with Google")
Route::get('auth/google/redirect', [GoogleController::class, 'redirect'])
    ->name('oauth.google.redirect');
Route::get('auth/google/callback', [GoogleController::class, 'callback'])
    ->name('oauth.google.callback');

// Logout (nếu bạn dùng trong view)
Route::post('/logout', function (Request $request) {
    Auth::guard('web')->logout();
    $request->session()->invalidate();
    $request->session()->regenerateToken();
    return redirect()->route('login');
})->name('logout');

// APP PAGES (đã đăng nhập + xác minh email)
Route::middleware(['auth', 'verified'])->group(function () {
    Route::view('/dashboard', 'dashboard')->name('dashboard');

    // Decks & Study (Livewire)
    Route::get('/decks', DeckIndex::class)->name('decks.index');
    Route::get('/decks/{deck}', DeckShow::class)->name('decks.show');
    Route::get('/decks/{deck}/study', StudyPanel::class)->name('study.panel');
    Route::get('/decks/{deck}/analytics', DeckAnalytics::class)->name('decks.analytics');

    // Analytics overview
    Route::get('/analytics/decks', DecksOverview::class)->name('analytics.decks');

    // NOTE: Alias để không vỡ các link cũ gọi route('analytics.index')
    Route::get('/analytics', DecksOverview::class)->name('analytics.index');

    // NOTE: Alias để không vỡ các link cũ gọi route('items.index')
    Route::get('/items', function () {
        return redirect()->route('decks.index');
    })->name('items.index');

    // NOTE: Alias để không vỡ các link cũ gọi route('settings')
    // Chuyển hướng về trang profile của Breeze (profile.edit)
    Route::get('/settings', function () {
        return redirect()->route('profile.edit');
    })->name('settings');
});

// Auth scaffolding (Breeze/Fortify/Jetstream)
// Trong Breeze, file này sẽ đăng ký route('profile.edit') v.v.
require __DIR__ . '/auth.php';
