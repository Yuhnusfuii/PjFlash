<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Http\Request;
use Illuminate\Cache\RateLimiting\Limit;

use App\Http\Controllers\Api\DeckController as ApiDeckController;
use App\Http\Controllers\Api\StudyController as ApiStudyController;

/*
|--------------------------------------------------------------------------
| API ROUTES (prefix /api)
|--------------------------------------------------------------------------
| Tất cả endpoint dùng cho Livewire/Alpine fetch để trong file này.
| Tránh để API ở web.php để không bị trùng tên/đụng middleware.
*/

/*
|--------------------------------------------------------------------------
| Rate Limiters
|--------------------------------------------------------------------------
*/
RateLimiter::for('api', function (Request $request) {
    return Limit::perMinute(120)
        ->by(optional($request->user())->id ?: $request->ip())
        ->response(function () {
            return response()->json(['message' => 'Too many requests. Please slow down.'], 429);
        });
});

RateLimiter::for('review', function (Request $request) {
    $userKey = optional($request->user())->id ?: $request->ip();
    $itemId  = (string)($request->route('item')?->id ?? $request->route('item'));

    return [
        Limit::perMinute(300)->by($userKey),
        Limit::perMinute(60)->by($userKey . '|item:' . $itemId),
    ];
});

RateLimiter::for('mcq_generate', function (Request $request) {
    $key = optional($request->user())->id ?: $request->ip();
    return [
        Limit::perMinute(10)->by($key),
        Limit::perDay(200)->by('day|' . $key),
    ];
});

RateLimiter::for('matching_generate', function (Request $request) {
    $key = optional($request->user())->id ?: $request->ip();
    return [
        Limit::perMinute(10)->by($key),
        Limit::perDay(200)->by('day|' . $key),
    ];
});

RateLimiter::for('import', function (Request $request) {
    $key = optional($request->user())->id ?: $request->ip();
    return [
        Limit::perMinute(6)->by($key),
        Limit::perDay(50)->by('day|' . $key),
    ];
});

/*
|--------------------------------------------------------------------------
| Protected API Routes (Sanctum)
|--------------------------------------------------------------------------
*/
Route::middleware('auth:sanctum')->group(function () {

    // A) Decks
    Route::get('decks', [ApiDeckController::class, 'index'])
        ->middleware('throttle:api')
        ->name('api.decks.index');

    Route::post('decks/{deck}/import', [ApiDeckController::class, 'import'])
        ->middleware('throttle:import')
        ->name('api.decks.import');

    // B) Study
    // NOTE: Thêm route name 'study.queue' để dashboard/nav gọi không lỗi.
    Route::get('study/queue', [ApiStudyController::class, 'queue'])
        ->middleware('throttle:review')
        ->name('study.queue');

    Route::post('study/{item}/review', [ApiStudyController::class, 'review'])
        ->middleware('throttle:review')
        ->name('api.study.review');

    // (Bước 9) Generators cho MCQ/Matching
    Route::post('items/{item}/mcq/generate', [ApiStudyController::class, 'generateMcq'])
        ->middleware('throttle:mcq_generate')
        ->name('api.items.mcq.generate');

    Route::post('items/{item}/matching/generate', [ApiStudyController::class, 'generateMatching'])
        ->middleware('throttle:matching_generate')
        ->name('api.items.matching.generate');
});
