{{-- resources/views/components/app-layout.blade.php --}}
<x-layouts.app>
    {{ $slot }}
</x-layouts.app>
