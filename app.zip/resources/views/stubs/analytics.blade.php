<x-app-layout>
  <div class="card p-6 view-fade">
    <h2 class="text-xl font-semibold">Đang phát triển</h2>
    <p class="mt-2 text-slate-600">Trang này sẽ được hoàn thiện ở các bước sau.</p>
  </div>
</x-app-layout>
