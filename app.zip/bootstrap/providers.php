<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\DomainServiceProvider::class,
    App\Providers\ServicesServiceProvider::class,
];
