/* public/js/matching.js
   Matching Game for Alpine + Livewire
   - Tự đăng ký Alpine.data('matchingGame', ...)
   - Không phụ thuộc thứ tự load: nếu Alpine đã có -> đăng ký ngay; nếu chưa -> đợi 'alpine:init'
*/
(function () {
  function defineMatching() {
    if (defineMatching._done) return;
    defineMatching._done = true;

    // Đăng ký component Alpine
    Alpine.data('matchingGame', ({ pairs = [], rights = [] } = {}) => {
      const P = (pairs || []).map(p => ({ left: String(p.left ?? p.l ?? ''), right: String(p.right ?? p.r ?? '') }))
        .filter(p => p.left && p.right);
      const R = (rights || []).map(r => String(r));

      const left = P.map(p => p.left);
      const rightOriginal = R.length ? R : P.map(p => p.right);

      const shuffled = arr => arr.map(v => ({ v, r: Math.random() }))
        .sort((a, b) => a.r - b.r)
        .map(o => o.v);

      return {
        // ----- state -----
        state: {
          left,
          right: shuffled(rightOriginal),
          pairs: {},              // {leftIndex: rightIndex}
          activeLeft: null,
          activeRight: null,
          submitted: false,
          correctCount: 0,
          total: left.length,
          mappedGrade: 0,
          scoreRatio: 0,
          anyWrong: false,
        },

        // ----- helpers -----
        correctIndexForLeft(i) {
          const correctRight = String((P[i] || {}).right ?? '');
          return this.state.right.findIndex(r => String(r) === correctRight);
        },
        hasPair(i) { return this.state.pairs[i] !== undefined; },
        pairIndexForRight(j) {
          for (const [i, rj] of Object.entries(this.state.pairs)) {
            if (Number(rj) === j) return Number(i);
          }
          return null;
        },
        isPickedRight(j) { return this.pairIndexForRight(j) !== null; },
        isLeftCorrect(i) {
          if (!this.state.submitted || !this.hasPair(i)) return false;
          return this.state.pairs[i] === this.correctIndexForLeft(i);
        },
        isRightCorrect(j) {
          if (!this.state.submitted) return false;
          const i = this.pairIndexForRight(j);
          if (i === null) return false;
          return this.isLeftCorrect(i);
        },
        badgeTextForRight(j) {
          const i = this.pairIndexForRight(j);
          return i === null ? '' : '#' + (i + 1);
        },
        badgeClassForRight(j) {
          if (!this.state.submitted) return 'bg-gray-100 border-gray-200 text-gray-500';
          return this.isRightCorrect(j)
            ? 'bg-emerald-50 border-emerald-300 text-emerald-700'
            : 'bg-red-50 border-red-300 text-red-700';
        },

        // ----- actions -----
        pickLeft(i) {
          if (this.state.submitted) return;
          this.state.activeLeft = i;
          this.state.activeRight = null;
        },
        pickRight(j) {
          if (this.state.submitted) return;
          if (this.state.activeLeft === null) { this.state.activeRight = j; return; }
          const usedBy = this.pairIndexForRight(j);
          if (usedBy !== null) delete this.state.pairs[usedBy];
          this.state.pairs[this.state.activeLeft] = j;
          this.state.activeLeft = null;
          this.state.activeRight = null;
        },
        shuffle() {
          if (this.state.submitted) return;
          this.state.right = shuffled(this.state.right);
          this.state.pairs = {};
          this.state.activeLeft = null;
          this.state.activeRight = null;
        },
        resetAll() {
          this.state.pairs = {};
          this.state.activeLeft = null;
          this.state.activeRight = null;
          this.state.submitted = false;
          this.state.correctCount = 0;
          this.state.mappedGrade = 0;
          this.state.scoreRatio = 0;
          this.state.anyWrong = false;
        },
        submit() {
          let correct = 0, total = this.state.total;
          for (let i = 0; i < total; i++) {
            if (this.state.pairs[i] !== undefined &&
              this.state.pairs[i] === this.correctIndexForLeft(i)) correct++;
          }
          const ratio = total > 0 ? correct / total : 0;
          let g = 1;
          if (ratio >= 0.9) g = 5;
          else if (ratio >= 0.6) g = 3;
          else if (ratio >= 0.3) g = 2;

          this.state.correctCount = correct;
          this.state.scoreRatio = ratio;
          this.state.mappedGrade = g;
          this.state.submitted = true;
          this.state.anyWrong = correct < total;

          if (window.$wire && typeof $wire.grade === 'function') $wire.grade(g);
        },
      };
    });
  }

  // Nếu Alpine đã sẵn -> đăng ký ngay; nếu chưa -> đợi 'alpine:init'
  if (window.Alpine && typeof Alpine.data === 'function') {
    defineMatching();
  } else {
    document.addEventListener('alpine:init', defineMatching, { once: true });
  }
})();
