self.addEventListener('install', (e) => self.skipWaiting());
self.addEventListener('activate', () => {});
self.addEventListener('fetch', () => {});
